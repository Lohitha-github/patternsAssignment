package stringbuliderandstringbuffer;

public class StringBuilderDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder strbuff = new StringBuilder("Hello ");
		strbuff.append("Hi ");
		System.out.println(strbuff);
		strbuff.append("StringBuilder");
		System.out.println(strbuff);


	}

}
