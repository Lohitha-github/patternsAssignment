package stringbuliderandstringbuffer;

public class StringBufferDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
            StringBuffer StrBuff= new StringBuffer("Demo");
            System.out.println(StrBuff.toString());
             //updating the string
            StrBuff.append(" to StringBuffer");
            System.out.println(StrBuff.toString());
      }



	}


