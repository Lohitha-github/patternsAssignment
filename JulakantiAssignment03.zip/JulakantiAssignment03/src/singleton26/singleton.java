package singleton26;

public class singleton {

	private static volatile singleton sin = null;
	private singleton() {
		
	}
	public static singleton getInstance() {
		if(sin==null) {
			synchronized (singleton.class) {
				if(sin==null) {
					sin = new singleton();
				}
				
			}
		}
		return sin;
	}
}
