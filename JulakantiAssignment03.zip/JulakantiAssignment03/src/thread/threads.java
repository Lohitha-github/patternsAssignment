package thread;

public class threads {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = "Lohitha";
		name.concat("Julakanti");
		System.out.println("name : " +name);
		Thread tr = new Thread(new Runnable() {
			public void run() {
				name.concat("tr");
				System.out.println("Thread: " +name);
				
			}

		});
		Thread th = new Thread(new Runnable() {
			public void run() {
				name.concat("th");
				System.out.println("Thread1 : " +name);
				
			}
			
		});
		tr.start();
		th.start();



	}

	}


