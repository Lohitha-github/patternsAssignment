package covriants;

public class Animal {
	public Animal getDetails(){ 
		   System.out.println(" animal class"
		   		+ ""); 
		    return this; 
		  } 


}
