package covriants;

public class Dog extends Animal {
	public Dog getDetails(){ 
	    System.out.println("Dog Class"); 
	     return this; 
	  } 
	  
	  public void sound() {
		  System.out.println("Dog will sound Bow Bow");
	  }
}



