package hashtableandhashmap;

import java.util.Hashtable;
import java.util.Map;

public class HashtableDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String,String> map = new Hashtable<String,String>();
		map.put("Lohi", "Lohitha");
		map.put("Mahesh", "Mahi");
		map.put("Anitha", "Aniii");
		map.put("Sweety", null);
		
		System.out.print("Elements in Hashtable are:\n " + map.entrySet());
		System.out.println(map.get("Lohi"));
		
	}


	}


