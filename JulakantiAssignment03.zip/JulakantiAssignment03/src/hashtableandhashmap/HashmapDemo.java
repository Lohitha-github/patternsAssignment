package hashtableandhashmap;

import java.util.HashMap;
import java.util.Map;

public class HashmapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String,String> map = new HashMap<String,String>();
		map.put("Lohi", "Lohitha");
		map.put("Mahesh", "Mahi");
		map.put("Anitha", "Aniii");
		map.put("Sweetha", null);
		map.put(null, null);
		map.put(null, "achu");
		
		System.out.print("Elements in Hashtable are:\n " + map.entrySet());
		System.out.println(map.get("Lohi"));
		System.out.println(map.get("achu"));
	}


	}


