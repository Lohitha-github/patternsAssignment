package stringclassandstringbuffer;

public class StringBufferDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer strbuff = new StringBuffer("Demo Class of StringBuffer");
        System.out.println(strbuff.toString());
        strbuff.reverse();
       System.out.println(strbuff.toString());
      }


	}


