package stringclassandstringbuffer;

public class StringClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String strr = "Lohitha";
	      String name = strr.toUpperCase();
	      System.out.println(name);
	      String add = strr.concat("Julakanti");
	      System.out.println(add);
	   }


	}


