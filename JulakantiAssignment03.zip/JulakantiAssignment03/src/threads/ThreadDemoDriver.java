package threads;

public class ThreadDemoDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadDemo t = new ThreadDemo();
		 
		t.start();
		//IllegalThreadStateException
		//t.start();
	}


	}


