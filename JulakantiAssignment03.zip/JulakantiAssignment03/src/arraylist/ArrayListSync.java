package arraylist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class ArrayListSync {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		list.add("lohitha");
		list.add("Mahesh");
		list.add("Anitha");
		list.add("Sweetha");
		
		list = Collections.synchronizedList(list);
		synchronized(list) {
			Iterator<String> itr = list.listIterator();
			while(itr.hasNext()) {
				System.out.println(itr.next());
			}
		}
	}


}


