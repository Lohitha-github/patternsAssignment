package arraylist;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListSync1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> namesList = new ArrayList<String>();
		namesList.add("lohitha");
		namesList.add("Mahesh");
		namesList.add("Anusha");
    System.out.println("Elements of synchronized ArrayList :");

    Iterator<String> iter = namesList.iterator();
    while (iter.hasNext())
        System.out.println(iter.next());
	}


	}


