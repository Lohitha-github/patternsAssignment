package singleton;

public  class Question27 {

	   private static Question27 instance = null;

	   private Question27() {}

	   public static Question27 getInstance() {
	       if (instance == null) {
	           instance = new Question27();
	       }

	       return instance;
	   }

}
