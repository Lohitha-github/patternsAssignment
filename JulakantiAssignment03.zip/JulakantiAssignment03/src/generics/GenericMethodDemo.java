package generics;

public class GenericMethodDemo {

		public static <Practice> void printArray(Practice[] input) {
			
			for(Practice practi: input) {
				System.out.print(practi + " ");
			}
			System.out.println();
		}
		
		public static void main(String[] args) {
			String[] names = {"Lohi", "Bittu"};
			System.out.println(" The generic method contains: ");
			printArray(names);
		}


}


