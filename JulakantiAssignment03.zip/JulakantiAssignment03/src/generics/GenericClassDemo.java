package generics;

public class GenericClassDemo<T> {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GenericClassDemo gen = new GenericClassDemo();
		gen.setName("Lohitha");
		System.out.println(gen);
	}

	private T name;

	public T getName() {
		return name;
	}

	public void setName(T name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "name= " + name;
	}
}


