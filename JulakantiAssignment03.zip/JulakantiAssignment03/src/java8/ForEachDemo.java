package java8;

import java.util.ArrayList;
import java.util.List;

public class ForEachDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> fruitList = new ArrayList<String>();  
        fruitList.add("Apple");  
        fruitList.add("Guava");  
        fruitList.add("Grapes");  
        fruitList.add("Mango");  
        fruitList.add("Strawberry");
        System.out.println("forEach Method");  
        fruitList.forEach(fruit -> System.out.println(fruit)); 
	}	



	}


