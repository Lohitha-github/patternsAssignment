package throwsdemo;

import java.io.FileNotFoundException;

public abstract class OverridingSuper {
	public void sampleMethod()throws FileNotFoundException
	{
        System.out.println("superclass method");
        }
  }



