package throwsdemo;

public class ExceptionDemo {
	public void sampleMethod() {
        System.out.println("Subclass method");
        }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExceptionDemo exde = new ExceptionDemo();
		exde.sampleMethod();
       }
}


