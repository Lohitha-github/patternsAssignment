package overridden;
public class Question2 {
public void PublicDemo() {
	
}
public void PrivateDemo() {
	
}
void DefaultMethodDemo() {
	
}
protected void ProtectedDemo() {
	
}
}