package overridden;


public class Driver {
	void PublicDemo() {
		//in public we cant change and we get an error
	}
	protected void DefaultMethodDemo() {
		
	}
	protected void ProtectedDemo() {
		

		}
}