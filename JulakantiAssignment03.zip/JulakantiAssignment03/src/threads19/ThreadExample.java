package threads19;

public class ThreadExample implements Runnable{
	public ThreadExample(){
        
    }
    public void run() {
    	System.out.println("thread starts");
    } 
}



