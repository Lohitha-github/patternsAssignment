package threads19;

public class ThreadDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Starting  of the Main Thread");
        ThreadExample thread = new ThreadExample();

         Thread thr = new Thread(thread);
         thr.start();
         System.out.println("End of the Main Thread");
       }
}

	


