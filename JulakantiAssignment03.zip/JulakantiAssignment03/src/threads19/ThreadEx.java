package threads19;

public class ThreadEx extends Thread {

	public void run(){
		System.out.println("thread starts");
	}
}


