package threads19;

public class ThreadExDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadEx thr = new ThreadEx();
		thr.start();



	}

}
