package arraylists;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListDemo {

       public static void main(String[] args) {
		// TODO Auto-generated method stub
    	   ArrayList arr = new ArrayList();
    	   arr.add("Lohitha");
    	   arr.add("Julakanti"); 
 
		// Traversing ArrayList elements
		System.out.println("al:"+arr); 
		Iterator iter = arr.iterator(); 
		while (iter.hasNext()) { 
			System.out.println(iter.next()); 
	}

	}
}

