package arraylists;

import java.util.Enumeration;
import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector vec = new Vector(); 	 
		//Adding elements to vector
		vec.addElement("Lohitha"); 
		vec.addElement("Julakanti");
		// Traversing vector elements
		System.out.println("Name:"); 
		Enumeration emp = vec.elements(); 
		while (emp.hasMoreElements()) { 
			System.out.println(emp.nextElement());
		}
	}


	}


