package immutable;

public final class Immutable {
	  private String name;
	  private int age;

	  public Immutable(String name, int date) {
	    this.name = name;
	    this.age = age;
	  }

	  // getter method
	  public String getName() {
	    return name;
	  }
	  public int getAge() {
	    return age;
	  }


}
