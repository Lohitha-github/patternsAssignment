package immutable;

public class ImmutableDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Immutable immm = new Immutable("Lohitha", 23);

	    System.out.println("Name: " + immm.getName());
	    System.out.println("Date: " + immm.getAge());


	}

}
