package garbage;

public class Garbage {
	protected void finalize() throws Throwable{
		System.out.println("Finalize called,hence garbage collector triggered");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Garbage gar = new Garbage();
		System.out.println("Calling garbage collector before making null");
		System.gc();
		gar = null;
		System.out.println("Calling garbage collector after making null");
		System.gc();
	}
		

	}


