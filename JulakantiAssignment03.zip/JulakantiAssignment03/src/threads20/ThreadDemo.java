package threads20;

public class ThreadDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		MyThread th = new MyThread();
		Thread th1 = new Thread(th);
		System.out.println("t1 state: " + th1.getState());//new
		th1.start();
		//runnable
		System.out.println("t1 state before main sleep : " +th1.getState());
		Thread.sleep(1000);
		System.out.println("t1 state after main sleep : " +th1.getState());//TIMED_WAITING
		Thread.sleep(2000);
		System.out.println("t1 state after 2 main sleep : " +th1.getState());//terminated
		
		
		

	}

}
class MyThread implements Runnable{
    	   public void run() {
    		   try {
    			   Thread.sleep(2500);
    			   System.out.println("t1 in run(), state: " + Thread.currentThread().getState());
    			   
    		   }catch(InterruptedException ec) {
    			   ec.printStackTrace();
    		   }
    	   }
       

	}


